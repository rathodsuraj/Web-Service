package com.wcs.webservice.crud.DaoIntref;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.wcs.webservice.crud.Model.Consumer;

public interface DaoIntref extends CrudRepository<Consumer, Integer> {
	
	
	public List<Consumer> findAllByUsernameAndPassword(String user,String pass);	

}
