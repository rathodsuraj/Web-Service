package com.wcs.webservice.crud.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wcs.webservice.crud.Model.Consumer;
import com.wcs.webservice.crud.ServiceIntref.ServiceIntref;

@RestController
public class HomeController {

	@Autowired
	ServiceIntref ser;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveData(@RequestBody Consumer con) {
		ser.saveConsumer(con);
		return "success";
	}

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public List<Consumer> getData(@ModelAttribute Consumer con) {
		List<Consumer> list = ser.getData();
		return list;
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	public String deleteData(@PathVariable("id") int id) {

		ser.deleteConsumer(id);

		return "success";

	}

	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public List<Consumer> update(@RequestBody Consumer con, @PathVariable("id") int i) {

		ser.saveConsumer(con);

		List<Consumer> list = ser.getData();
		return list;
	}

	@RequestMapping(value = "/login{username}{password}", method = RequestMethod.GET)
	public List<Consumer> login(@PathVariable("username") String un, @PathVariable("password") String pw) {

		List l = new ArrayList<>();
		l.add("not valid uname");

		if (un.equals("admin") && pw.equals("admin")) {
			List<Consumer> list = ser.getData();
			return list;
		} else if (un.equals(un) && pw.equals(pw)) {
			List<Consumer> list = ser.getConsumerData(un, pw);
			return list;
		}

		return l;
	}

}
