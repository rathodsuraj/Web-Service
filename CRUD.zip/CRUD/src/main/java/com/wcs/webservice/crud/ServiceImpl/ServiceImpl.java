package com.wcs.webservice.crud.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcs.webservice.crud.DaoIntref.DaoIntref;
import com.wcs.webservice.crud.Model.Consumer;
import com.wcs.webservice.crud.ServiceIntref.ServiceIntref;

@Service
public class ServiceImpl implements ServiceIntref {

	@Autowired
	DaoIntref dao;

	@Override
	public void saveConsumer(Consumer con) {
		dao.save(con);
	}

	@Override
	public List<Consumer> getData() {

		List<Consumer> list = (List<Consumer>) dao.findAll();

		return list;
	}

	@Override
	public void deleteConsumer(int id) {

		dao.deleteById(id);

	}

	@Override
	public void updateCounsumer(Consumer con) {

		dao.save(con);

	}

	@Override
	public List<Consumer> getConsumerData(String user, String pass) {
		List<Consumer> list = dao.findAllByUsernameAndPassword(user, pass);
		return list;
	}

}
