package com.wcs.webservice.crud.ServiceIntref;

import java.util.List;

import com.wcs.webservice.crud.Model.Consumer;

public interface ServiceIntref {

	
	public void saveConsumer(Consumer con);
	
	public List<Consumer> getData();
	
	public void deleteConsumer(int id);
	
	public void updateCounsumer(Consumer con);
	
	public List<Consumer> getConsumerData(String un,String pw);
}
